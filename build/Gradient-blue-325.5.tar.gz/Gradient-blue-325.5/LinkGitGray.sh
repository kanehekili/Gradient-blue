#!/usr/bin/bash
ln -s ~/git/Gradient-blue/Cinnamon/cinnamon cinnamon
ln -s ~/git/Gradient-blue/GTK-3.22/src/Gradient-blue-324.2/gnome-shell gnome-shell
ln -s ~/git/Gradient-blue/GTK-3.22/src/Gradient-blue-324.2/gtk-2.0 gtk-2.0
ln -s ~/git/Gradient-blue/GTK-3.22/src/Gradient-blue-324.2/gtk-3.0 gtk-3.0
ln -s ~/git/Gradient-blue/metacity/Gradient-blue/metacity-1 metacity-1
ln -s ~/git/Gradient-blue/xfwm4/Gradient-blue/xfce-notify-4.0 xfce-notify-4.0
ln -s ~/git/Gradient-blue/xfwm4/Gradient-blue/xfwm4 xfwm4
ln -s ~/git/Gradient-blue/GTK-3.22/src/Gradient-blue-324.2/index.theme index.theme
ln -s /home/matze/git/Gradient-blue/metacity/Gradient-blue/metacity-1 gtk-3.0/csd